       
        </div>  <!-- <div class="content"> -->

                   <?php
                         $footer_image=get_field('footer_image');
                    ?>
            <footer class="footer" style="background: url(<?php echo $footer_image[1]['original'];?>) no-repeat; background-size: 100% auto; padding-top:20px;" itemscope="itemscope" itemtype="http://schema.org/WPFooter">
                   
                    <div class="container">
                                                 
                             <div class="row-fluid">
                            
                                <div class="col-md-2" >
                                    <a href="tel:+380577800551" class="turq"<span >+38 (057)</span> 78-00-551</a>
                                    <a href="mailto:tour@koleso-f.com.ua" class="turq"> <span>tour@koleso-f.com.ua</span></a>
                                    <span class="info_social">
                                        <a href="https://www.facebook.com/iskolesi"><img src="<?php echo get_template_directory_uri(); ?>/img/facebook.png"></a>
                                        <a href="https://vk.com/club16117273"><img src="<?php echo get_template_directory_uri(); ?>/img/vk.png"></a>
                                        <a href="https://www.instagram.com/kolesotur"><img src="<?php echo get_template_directory_uri(); ?>/img/twitter.png"></a>
                                    </span>
                                </div>

                                <div class="col-md-6">
                                     <p class="all_right">All rights reserved (c) 2016</p>
                                </div>

                                <div class="col-md-4">
                                      <span class="redesign">Redesign by <a href="http://perfectorium.com">Perfectorium</a></span> 
                                </div>
                              
                            </div>

                         </div>

              
                        <div class="callback"><img src="<?php echo get_template_directory_uri(); ?>/img/callback.png"></div>
                        <div class="scrollup"><img src="<?php echo get_template_directory_uri(); ?>/img/scrollup.png"></div>
                    
                </div>    
             
             </footer>

     <?php wp_footer(); ?>

</div> <!-- <div class="wrapper"> -->

   </body>
</html>
