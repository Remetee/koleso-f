
<?php get_header(); ?>

<img src="<?php echo get_template_directory_uri(); ?>/img/news_header.png" style="width:100%">

<h1 class="new"><?php the_title();?></h1>

<div class="container">
	
			<div class="row">
					
						<?php
							if (have_posts()) : while (have_posts()) : the_post();?>
								<div class="col-md-8 new">

									<p>	<?php $main_image=get_field('cat_main');?>
										<img src="<?php echo $main_image[1]['original']?>">
									</p>
									<div>
										<?php the_content();?>
									</div>
								</div>

								<div class="col-md-4 new">

									<aside class="sidebar" role="complementary">
									<?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar')){ } ?>
									</aside>

								</div>
																
							<?php
					 		endwhile;
							endif;
						?>

			</div>

</div>

<img src="<?php echo get_template_directory_uri(); ?>/img/news_footer.png" style="width:100%; position:absolute; bottom:0;">
<?php get_footer(); ?>

