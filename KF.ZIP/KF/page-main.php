<?php
/**
 * Template Name: Template Main
 */?>

<?php get_header(); ?>
<?php echo do_shortcode('[owl-carousel category="slideshow" items="1" autoPlay="true" singleItem="true" rewindSpeed="10" rewindNav="true" navigation="true" navigationText="false"]'); ?>

<div class="container" role="main">

	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			
				<?php if ( has_post_thumbnail() ) { the_post_thumbnail(); } ?>
				<?php the_content(); ?>
	<?php endwhile; endif; ?>
</div>
 <img src="<?php echo get_template_directory_uri(); ?>/img/footer.png" style="width:100%; position:absolute; bottom:0; padding-top:30px;">

<?php get_footer(); ?>