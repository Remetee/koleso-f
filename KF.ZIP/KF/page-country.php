<?php
/**
 * Template Name: Template Country
 */?>

<?php get_header(); ?>

<img src="<?php echo get_template_directory_uri(); ?>/img/Greece_gold_beach.png" style="width:100%">

<div class="container" role="main">

	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			
				<?php if ( has_post_thumbnail() ) { the_post_thumbnail(); } ?>
				<?php the_content(); ?>
	<?php endwhile; endif; ?>

</div>

<img src="<?php echo get_template_directory_uri(); ?>/img/footer.png" style="width:100%; position:absolute; bottom:0; padding-top:30px;">
<?php get_footer(); ?>