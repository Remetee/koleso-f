
<?php get_header(); ?>

<img src="<?php echo get_template_directory_uri(); ?>/img/news_header.png" style="width:100%">

<div class="container">

	<h1><?php echo single_cat_title();?></h1>
	
			<div class="row">
					
						<?php
							if (have_posts()) : while (have_posts()) : the_post();?>
								<div class="col-md-5 goodknow">
									<a href="<?php the_permalink(); ?>"><?the_post_thumbnail();?></a>
								</div>	
								<div class="col-md-7 goodknow">
									<a href="<?php the_permalink(); ?>"><span><?php the_title();?></span></a>
									<p> <?php the_excerpt();?> 
									<p>Читать далее <a href="<?php the_permalink(); ?>" ><img src="<?php echo get_template_directory_uri(); ?>/img/follow.png"></a></p>
								</div>
									
									
								
							<?php
					 			endwhile;
							endif;
						?>

			</div>

			
</div>

<img src="<?php echo get_template_directory_uri(); ?>/img/news_footer.png" style="width:100%; position:absolute; bottom:0;">
<?php get_footer(); ?>


