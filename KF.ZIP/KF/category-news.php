
<?php get_header(); ?>

<img src="<?php echo get_template_directory_uri(); ?>/img/news_header.png" style="width:100%">

<div class="container">

	

		<h1><?php echo single_cat_title();?></h1>
	
			<div class="row">
					
						<?php

							if (have_posts() & query_posts('showposts=6&category_name=news')) : while (have_posts()) : the_post();?>
								
								<div class="col-md-4 news">
									<a href="<?php the_permalink(); ?>"><?the_post_thumbnail();?></a>
									</br>
									<a href="<?php the_permalink(); ?>"><span><?php the_title();?></span></a>
									</br>
									<p>Читать далее <a href="<?php the_permalink(); ?>" ><img src="<?php echo get_template_directory_uri(); ?>/img/follow.png"></a></p>
									<p style="font-size: 10px;">
									<img src="<?php echo get_template_directory_uri(); ?>/img/clock.png"><?php the_date('j F Y');?>
									</p>
								</div>
								
							<?php
					 			endwhile;
							endif;?>
			</div>

	

			<div class="row news_important">
								<?php query_posts('category_name=important')?><h1><?php echo single_cat_title();?></h1>

							<?php if (have_posts() & query_posts('showposts=3&category_name=important')) : while (have_posts()) : the_post();?>
									
								<div class="col-md-4 news">
									<a href="<?php the_permalink(); ?>"><span><?php the_title();?></span></a>
									</br>
									<p>Читать далее <a href="<?php the_permalink(); ?>" ><img src="<?php echo get_template_directory_uri(); ?>/img/follow.png"></a></p>
									<p style="font-size: 10px;">
									<img src="<?php echo get_template_directory_uri(); ?>/img/clock.png"><?php the_date('j F Y');?>
									</p>
								</div>
								
							<?php
					 			endwhile;
							endif;

						?>

			</div>

			<div class="row">
					
						<?php
							wp_count_posts();
							if (have_posts() & query_posts('category_name=news')) : while (have_posts()) : the_post();?>

								<div class="col-md-4 news">
									<a href="<?php the_permalink(); ?>"><?the_post_thumbnail();?></a>
									</br>
									<a href="<?php the_permalink(); ?>"><span><?php the_title();?></span></a>
									</br>
									<p>Читать далее <a href="<?php the_permalink(); ?>" ><img src="<?php echo get_template_directory_uri(); ?>/img/follow.png"></a></p>
									<p style="font-size: 10px;">
									<img src="<?php echo get_template_directory_uri(); ?>/img/clock.png"><?php the_date('j F Y');?>
									</p>
								</div>
								
							<?php
					 			endwhile;
							endif;?>
			</div>


	<p style="text-align: center;"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/show_more.png"></a></p>	
</div>

<img src="<?php echo get_template_directory_uri(); ?>/img/news_footer.png" style="width:100%; position:absolute; bottom:0;">
<?php get_footer(); ?>


