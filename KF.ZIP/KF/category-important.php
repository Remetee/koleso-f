
<?php get_header(); ?>
	<img src="<?php echo get_template_directory_uri(); ?>/img/news_header.png" style="width:100%red">
	<h3 class="news"><?php echo single_cat_title();?></h3>
<!-- <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2> -->
	<div class="container-fluid news">
		<div class="row">
			
			<?php
			if (have_posts()) : while (have_posts()) : the_post();?>
				<div class="col-md-4 news_title">
					<?the_post_thumbnail();?>
					</br>
					<p><?php the_title();?></p>
					</br>
					<?the_date();?>
					</br>
					<b>Читать далее</b>
					<?single_term_title();
					 	echo "</br>";
						single_cat_title('Вы находитесь в категории: ');;
						 the_excerpt() ;
						
						  ?>
				</div>
			<?php
			 		endwhile;
			endif;
			?>
		</div>
	</div>

<?php get_footer(); ?>