<?php

function koleso_scripts() {
 wp_enqueue_style( 'bootstrap.min', get_template_directory_uri().'/css/bootstrap.min.css');
 wp_enqueue_style( 'bootstrap-theme.min', get_template_directory_uri().'/css/bootstrap-theme.min.css');
 wp_enqueue_script( 'bootstrap.min', get_template_directory_uri().'/js/bootstrap.min.js', array('jquery'), false, true);
 wp_enqueue_style( 'styles', get_stylesheet_uri() );
 wp_enqueue_script( 'custom', get_template_directory_uri().'/js/custom.js', array('jquery'), false, true );
 }

add_action( 'wp_enqueue_scripts', 'koleso_scripts' );

add_filter( 'pre_option_link_manager_enabled', '__return_true' ); // добавление ссылок в админку

function register_my_menu() {
    register_nav_menu('header-menu',__( 'Header Menu' ));
}
add_action( 'init', 'register_my_menu' );


function js_scripts() {
	wp_enqueue_script( 'scrollup', get_template_directory_uri().'/js/scrollup.js');
}
add_action( 'wp_enqueue_scripts', 'js_scripts' );

add_theme_support( 'post-thumbnails', array( 'post' ) ); // миниатюра записей


function wp_get_cat_postnum($id) {
    $cat = get_category($id);
    $count = (int) $cat->count;
    $taxonomy = 'category';
    $args = array(
      'child_of' => $id,
    );
    $tax_terms = get_terms($taxonomy,$args);
    foreach ($tax_terms as $tax_term) {
        $count +=$tax_term->count;
    }
    return $count;
}

add_theme_support( 'post-thumbnails' );


if (function_exists('register_sidebar')){
		 register_sidebar( array(
		     'name'         => __( 'Right Sidebar' ),
		     'id'           => 'sidebar',
		     'description'  => __( 'Widgets in this area will be shown on the right-hand side.' ),
		     'class'        => '',
		     'before_widget'=> '<section id="%1$s" class="widget %2$s">',
		     'after_widget' => '</section>',
		     'before_title' => '<h3>',
		     'after_title'  => '</h3>'
		 ));
}



function recentTours($atts){

      $html = '';
      $regions = get_terms( 'region', array(
     'orderby'    => 'count',
     'hide_empty' => 0    ) );
     
 foreach($regions as $region){

      if (function_exists('get_all_wp_terms_meta')){ 
         $regionData = get_all_wp_terms_meta($region->term_id);
        }
          $args = array(
             'posts_per_page' => 1,
             'offset'=> 0,
             'post_type' => 'tour',
             'tax_query' => array(
                     array(
                         'taxonomy' => 'region',
                         'field' => 'term_id',
                         'terms' => $region->term_id,
                     )
                 ),
             'meta_key' => 'tour_price',
             'orderby' => 'meta_value',
             'order' => 'ASC',
          );
      
  $tours = get_posts( $args );
    if(count($tours) > 0){
      $country_id  = $region->id;
      $country_region  = $region->name;
      $tour_id     = $tours[0]->ID;
      $tour_price    = $tours[0]->tour_price;
      $tour_fly    = $tours[0]->tour_fly;
      $tour_date     = $tours[0]->tour_date;
      $hotel_stars   = $tours[0]->hotel_stars;  
      $duration_nights = $tours[0]->duration_nights;
  $html .= "<div class=\"col-md-4 hot3\">";
  $html .= '<div class="hot_corner"></div>';
  $html .= '<a href="'.get_term_link($region->term_id, 'region').'"><p class="hot_region">'. $country_region . '</p></a>' ; 
  $html .= '<p class="hot_price">' .  $tour_price . '</p>' ;
  $html .= '<p class="hot_fly">' .  $tour_fly . '</p>' ; 
  $html .= '<p class="hot_date">' .  $tour_date . '</p>' ;
  $html .= '<p class="hot_duration_nights">' .  $duration_nights . ' ночей</p>' ;
  $html .= '<div class="hot_stars">
                 <img src="'.get_template_directory_uri().'/img/'.$hotel_stars.'hotel_stars.png">
                 </div>' ;
  $html .= '</div>';
      }

 }
echo $country_id;

  return $html;

};

add_shortcode('newTours', 'recentTours');

?>