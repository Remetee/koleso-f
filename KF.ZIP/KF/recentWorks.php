<?php 

function recentWorks($atts){
     $category_id = 100;
     $html = '<div class="recentWorks">';
     $args = array('posts_per_page' => 4,
         'offset'=> 0,
         'post_type' => 'works',
         'meta_query' => array(
          array(
           'key' => '_thumbnail_id'
          ),
          array(
           'key' => 'work_home',
           'value' => 1
          )
         )
     );
 $works = get_posts( $args );
 foreach ($works as $work) {
  if ( has_post_thumbnail($work->ID)) {
   $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($work->ID) , 'full');
   $html .= '<a href="' . get_permalink( $work->ID ) . '" title="' . esc_attr( $work->post_title ) . '" style="background-image:url('.$thumb[0].');"  target="_blank">';
   $html .= esc_attr( $work->post_title );
   $html .= '</a>';
  }
 }
 $html .= '<a href="' . get_category_link($category_id) . '" class="last" title="'.get_the_category_by_ID( $category_id ).'" target="_blank">+</a>';
 $html .= '<div style="clear:both"></div>';
 $html .= '</div>';
 return $html;
}

add_shortcode('newWorks', 'recentWorks');
?>